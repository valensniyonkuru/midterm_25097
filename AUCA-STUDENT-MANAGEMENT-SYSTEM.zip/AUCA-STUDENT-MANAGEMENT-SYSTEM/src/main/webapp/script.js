function validateForm() {
    
    alert("Login form validated!");
    return false; 
}

function validateSignupForm() {
    
    
    alert("Signup form validated!");
    return false; 
}

function validateForgotPasswordForm() {
    
    alert("Forgot Password form validated!");
    return false; 
}
