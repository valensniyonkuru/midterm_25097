package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name = "Course_Definition")

public class CourseDefinition  {
	@Id
	@OneToOne
	@JoinColumn(name = "id")
	private String course_definition_id;
	private String course_definition_code;
	private String course_definition_description;
	private String course_id;
	public CourseDefinition() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseDefinition(String course_definition_id, String course_definition_code,
			String course_definition_description, String course_id) {
		super();
		this.course_definition_id = course_definition_id;
		this.course_definition_code = course_definition_code;
		this.course_definition_description = course_definition_description;
		this.course_id = course_id;
	}
	public String getCourse_definition_id() {
		return course_definition_id;
	}
	public void setCourse_definition_id(String course_definition_id) {
		this.course_definition_id = course_definition_id;
	}
	public String getCourse_definition_code() {
		return course_definition_code;
	}
	public void setCourse_definition_code(String course_definition_code) {
		this.course_definition_code = course_definition_code;
	}
	public String getCourse_definition_description() {
		return course_definition_description;
	}
	public void setCourse_definition_description(String course_definition_description) {
		this.course_definition_description = course_definition_description;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String courseId) {
		this.course_id = courseId;
	}
	public void setCourseDefinitionCode(String courseDefinitionCode) {
		// TODO Auto-generated method stub
		
	}
	
}
	