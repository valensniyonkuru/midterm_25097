package servletclass;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CourseDefinitionDao;
import model.CourseDefinition;

@WebServlet("/CourseDefinitionServlet")
public class CourseDefinitionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String courseDefinitionId = request.getParameter("courseDefinitionId");
        String courseDefinitionCode = request.getParameter("courseDefinitionCode");
        String courseDefinitionDescription = request.getParameter("courseDefinitionDescription");
        String courseId = request.getParameter("courseId");

        // Create CourseDefinition object
        CourseDefinition courseDefinition = new CourseDefinition();
        courseDefinition.setCourse_definition_id(courseDefinitionId);
        courseDefinition.setCourse_definition_code(courseDefinitionCode);
        courseDefinition.setCourse_definition_description(courseDefinitionDescription);
        courseDefinition.setCourse_id(courseId); // Corrected method name

        // Save the course definition using DAO
        CourseDefinitionDao courseDefinitionDao = new CourseDefinitionDao();
        courseDefinitionDao.saveCourseDefinition(courseDefinition);

        // Redirect to a success page
        response.sendRedirect("courseDefinitionSuccess.jsp");
    }
}
