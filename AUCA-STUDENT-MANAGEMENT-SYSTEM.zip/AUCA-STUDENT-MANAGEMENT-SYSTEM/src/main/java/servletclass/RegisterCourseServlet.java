package servletclass;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CourseDAO;
import model.Course;

@WebServlet("/RegisterCourseServlet")
public class RegisterCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve course details from the form
        String courseId = request.getParameter("courseId");
        String courseCode = request.getParameter("courseCode");
        String courseName = request.getParameter("courseName");

        // Create Course object
        Course course = new Course();
        course.setCourse_id(courseId);
        course.setCourse_code(courseCode);
        course.setCourse_name(courseName);

        // Save course using CourseDAO
        CourseDAO courseDAO = new CourseDAO();
        courseDAO.registerCourse(course);

        // Redirect to a success page or display a confirmation message
        response.sendRedirect("registrationSuccess.jsp");
    }
}
