package servletclass;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.AcademicUnitDao;
import model.AcademicUnit;

@WebServlet("/AcademicUnitRegistrationServlet")
public class AcademicUnitRegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String academicId = request.getParameter("academic_id");
        String academicCode = request.getParameter("academic_code");
        String academicName = request.getParameter("academic_name");
        String type = request.getParameter("type");
        String parentId = request.getParameter("parent_id");

        // Create AcademicUnit object
        AcademicUnit<String> academicUnit = new AcademicUnit<>();
        academicUnit.setAcademic_id(academicId);
        academicUnit.setAcademic_code(academicCode);
        academicUnit.setAcademic_name(academicName);
        academicUnit.setType(type);
        academicUnit.setParent_id(parentId);

        // Save the academic unit using DAO
        AcademicUnitDao academicUnitDao = new AcademicUnitDao();
        academicUnitDao.registerAcademicUnit(academicUnit);

        // Redirect to a success page
        response.sendRedirect("academicUnitRegistrationSuccess.jsp");
    }
}
