package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import model.AcademicUnit;
import dao.HibernateUtil;

public class AcademicUnitDao {

    public void registerAcademicUnit(AcademicUnit academicUnit) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start a transaction
            transaction = session.beginTransaction();
            
            // Save the academic unit
            session.save(academicUnit);
            
            // Commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
