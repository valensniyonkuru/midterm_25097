package model;

public enum EQualification {

	 MASTER,
	    PHD,
	    PROFESSOR
}
