package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import java.util.List;

@Entity
@Table(name = "teachers")
public class Teacher {
    @Id
    private String teacher_id;
    private String first_name;
    private String last_name;

    @Enumerated(EnumType.STRING)
    private EQualification qualification1;

    private String course_id;

    @Enumerated(EnumType.STRING)
    private EQualification qualification;

    @ManyToMany
    @JoinTable(
        name = "teacher_academicunit",
        joinColumns = @JoinColumn(name = "teacher_id"),
        inverseJoinColumns = @JoinColumn(name = "academicunit_id")
    )
    private List<AcademicUnit> academicUnits;

    public Teacher() {
        super();
    }

    public Teacher(String teacher_id, String first_name, String last_name, EQualification qualification,
                   String course_id, List<AcademicUnit> academicUnits) {
        super();
        this.teacher_id = teacher_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.qualification1 = qualification;
        this.course_id = course_id;
        this.academicUnits = academicUnits;
    }

    public String getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(String teacher_id) {
        this.teacher_id = teacher_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public EQualification getQualification1() {
        return qualification1;
    }

    public void setQualification1(EQualification qualification1) {
        this.qualification1 = qualification1;
    }

    public String getCourse_id() {
        return course_id;
    }

    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }

    public EQualification getQualification() {
        return qualification;
    }

    public void setQualification(EQualification qualification) {
        this.qualification = qualification;
    }

    public List<AcademicUnit> getAcademicUnits() {
        return academicUnits;
    }

    public void setAcademicUnits(List<AcademicUnit> academicUnits) {
        this.academicUnits = academicUnits;
    }
}
