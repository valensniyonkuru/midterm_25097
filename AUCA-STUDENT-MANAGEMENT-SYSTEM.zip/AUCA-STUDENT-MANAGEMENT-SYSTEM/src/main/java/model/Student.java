package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import java.util.List;

import java.time.LocalDate;



//import javax.persistence.*;
@Entity
@Table(name = "students")
public class Student {

	 @Id
	 @Column(name = "id")
	    private String student_id;
	  @Column(name = "first_name")
	    private String first_name;
	  @Column(name = "last_name")
	    private String last_name;
	  @Column(name = " date")
	    private LocalDate date_of_birth;
	  
	  @ManyToMany
	    @Column(name = "student_course")
	 	private List<Course> courses;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String student_id, String first_name, String last_name, LocalDate date_of_birth,
			List<Course> courses) {
		super();
		this.student_id = student_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.date_of_birth = date_of_birth;
		this.courses = courses;
	}

	public String getStudent_id() {
		return student_id;
	}

	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public LocalDate getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(LocalDate date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	    
}