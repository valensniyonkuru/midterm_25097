
package servletclass;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.StudentRegistrationDao;
import model.Student;
import model.Semester;
import model.StudentRegistration;

@WebServlet("/StudentRegistrationServlet")
public class StudentRegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String registrationCode = request.getParameter("registrationCode");
        String registrationDateStr = request.getParameter("registrationDate");
        String studentId = request.getParameter("studentId");
        String semesterId = request.getParameter("semesterId");

        // Parse registration date
        LocalDate registrationDate = LocalDate.parse(registrationDateStr);

        // Create Student object
        Student student = new Student();
        student.setStudent_id(studentId); // Assuming you have this setter method

        // Create Semester object
        Semester semester = new Semester();
        semester.setSemester_id(semesterId); // Assuming you have this setter method

        // Create StudentRegistration object
        StudentRegistration studentRegistration = new StudentRegistration();
        studentRegistration.setRegistrationCode(registrationCode);
        studentRegistration.setRegistrationDate(registrationDate);
        studentRegistration.setStudent(student);
        studentRegistration.setSemester(semester);

        // Save the student registration using DAO
        StudentRegistrationDao studentRegistrationDao = new StudentRegistrationDao();
        studentRegistrationDao.saveStudentRegistration(studentRegistration);

        // Redirect to a success page
        response.sendRedirect("studentRegistrationSuccess.jsp");
    }
}
