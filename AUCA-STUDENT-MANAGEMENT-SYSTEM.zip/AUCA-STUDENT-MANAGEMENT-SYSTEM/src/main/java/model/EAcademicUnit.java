package model;

public enum EAcademicUnit {
	 PROGRAMME,
	    FACULTY,
	    DEPARTMENT
}
