package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



import java.util.List;

@Entity
@Table(name = "academic_unit")
public class AcademicUnit<AcademicUnity> {
	 @Id
	    
	    @Column(name = "id")
	private String academic_id;
	 @Column(name = "academic_code")
	private String academic_code;
	 @Column(name = "academic_name")
	private String academic_name;
	 @Column(name = "type")
	private String type;
	 @Column(name = "parent_id")
	private String parent_id;
	 
	 @Enumerated(EnumType.STRING)
	    @Column(name = "type")
	    private EAcademicUnit type1;
	 
	 @ManyToMany
	    @JoinTable(
	        name = "teacher_academicunit",
	        joinColumns = @JoinColumn(name = "academicunit_id"),
	        inverseJoinColumns = @JoinColumn(name = "teacher_id")
	    )
	    private List<Teacher> teachers;
	    
	    @ManyToOne
	    @JoinColumn(name = "unit")
	    private AcademicUnity unit;

		public AcademicUnit() {
			super();
			// TODO Auto-generated constructor stub
		}

		public AcademicUnit(String academic_id, String academic_code, String academic_name, String type,
				String parent_id, EAcademicUnit type1, List<Teacher> teachers, AcademicUnity unit) {
			super();
			this.academic_id = academic_id;
			this.academic_code = academic_code;
			this.academic_name = academic_name;
			this.type = type;
			this.parent_id = parent_id;
			this.type1 = type1;
			this.teachers = teachers;
			this.unit = unit;
		}

		public String getAcademic_id() {
			return academic_id;
		}

		public void setAcademic_id(String academic_id) {
			this.academic_id = academic_id;
		}

		public String getAcademic_code() {
			return academic_code;
		}

		public void setAcademic_code(String academic_code) {
			this.academic_code = academic_code;
		}

		public String getAcademic_name() {
			return academic_name;
		}

		public void setAcademic_name(String academic_name) {
			this.academic_name = academic_name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getParent_id() {
			return parent_id;
		}

		public void setParent_id(String parent_id) {
			this.parent_id = parent_id;
		}

		public EAcademicUnit getType1() {
			return type1;
		}

		public void setType1(EAcademicUnit type1) {
			this.type1 = type1;
		}

		public List<Teacher> getTeachers() {
			return teachers;
		}

		public void setTeachers(List<Teacher> teachers) {
			this.teachers = teachers;
		}

		public AcademicUnity getUnit() {
			return unit;
		}

		public void setUnit(AcademicUnity unit) {
			this.unit = unit;
		}

		
			

}
	