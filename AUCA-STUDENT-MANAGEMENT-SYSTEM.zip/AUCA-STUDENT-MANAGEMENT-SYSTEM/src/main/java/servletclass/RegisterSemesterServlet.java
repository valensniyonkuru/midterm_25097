package servletclass;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.SemesterDAO;
import model.Semester;

@WebServlet("/RegisterSemesterServlet")
public class RegisterSemesterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve semester details from the form
        String semesterId = request.getParameter("semesterId");
        String semesterName = request.getParameter("semesterName");
        LocalDate startDate = LocalDate.parse(request.getParameter("startDate"));
        LocalDate endDate = LocalDate.parse(request.getParameter("endDate"));

        // Create Semester object
        Semester semester = new Semester();
        semester.setSemester_id(semesterId);
        semester.setSemester_name(semesterName);
        semester.setStartDate(startDate);
        semester.setEndDate(endDate);

        // Save semester using SemesterDAO
        SemesterDAO semesterDAO = new SemesterDAO();
        semesterDAO.registerSemester(semester);

        // Redirect to a success page or display a confirmation message
        response.sendRedirect("registrationSuccess.jsp");
    }
}
