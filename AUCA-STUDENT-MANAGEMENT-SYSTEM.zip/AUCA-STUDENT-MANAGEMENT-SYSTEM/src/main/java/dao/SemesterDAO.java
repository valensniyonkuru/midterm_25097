package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import model.Semester;
import dao.HibernateUtil;

public class SemesterDAO {
    private SessionFactory sessionFactory;

    public SemesterDAO() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }

    public void registerSemester(Semester semester) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(semester);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
