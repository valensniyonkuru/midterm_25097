package model;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name = "course")
public class Course {
	 @Id
	 @Column(name = "id")
	private String course_id;
	 @Column(name = "course_code")
	private String course_code;
	 @Column(name = "course_name")
	private String course_name;
	 @Column(name = "semester_id")
	private Semester semester_id;
	 @Column(name = "department_id")
	private  AcademicUnit department_id;
	 
	  @ManyToMany(mappedBy = "courses")
	    private List<Student> students;

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Course(String course_id, String course_code, String course_name, Semester semester_id,
			AcademicUnit department_id, List<Student> students) {
		super();
		this.course_id = course_id;
		this.course_code = course_code;
		this.course_name = course_name;
		this.semester_id = semester_id;
		this.department_id = department_id;
		this.students = students;
	}

	public String getCourse_id() {
		return course_id;
	}

	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}

	public String getCourse_code() {
		return course_code;
	}

	public void setCourse_code(String course_code) {
		this.course_code = course_code;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public Semester getSemester_id() {
		return semester_id;
	}

	public void setSemester_id(Semester semester_id) {
		this.semester_id = semester_id;
	}

	public AcademicUnit getDepartment_id() {
		return department_id;
	}

	public void setDepartment_id(AcademicUnit department_id) {
		this.department_id = department_id;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
	  
}
