package servletclass;

import dao.TeacherDao;
import model.EQualification;
import model.Teacher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/TeacherRegistrationServlet")
public class TeacherRegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String teacherId = request.getParameter("teacherId");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String qualificationStr = request.getParameter("qualification");
        String courseId = request.getParameter("courseId");

        // Convert qualification string to enum
        EQualification qualification = EQualification.valueOf(qualificationStr);

        // Create Teacher object
        Teacher teacher = new Teacher();
        teacher.setTeacher_id(teacherId);
        teacher.setFirst_name(firstName);
        teacher.setLast_name(lastName);
        teacher.setQualification(qualification);
        teacher.setCourse_id(courseId);

        // Save the teacher using DAO
        TeacherDao teacherDao = new TeacherDao();
        teacherDao.saveTeacher(teacher);

        // Redirect to a success page
        response.sendRedirect("teacherRegistrationSuccess.jsp");
    }
}
