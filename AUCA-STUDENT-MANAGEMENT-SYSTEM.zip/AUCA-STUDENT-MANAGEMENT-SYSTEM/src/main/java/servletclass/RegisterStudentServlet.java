package servletclass;

import java.io.IOException;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.StudentDAO;
import model.Student;

@WebServlet("/RegisterStudentServlet")
public class RegisterStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve student details from the form
        String studentId = request.getParameter("studentId");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        LocalDate dateOfBirth = LocalDate.parse(request.getParameter("dateOfBirth"));

        // Create Student object
        Student student = new Student();
        student.setStudent_id(studentId);
        student.setFirst_name(firstName);
        student.setLast_name(lastName);
        student.setDate_of_birth(dateOfBirth);

        // Save student using StudentDAO
        StudentDAO studentDAO = new StudentDAO();
        studentDAO.registerStudent(student);

        // Redirect to a success page or display a confirmation message
        response.sendRedirect("registrationSuccess.jsp");
    }
}
