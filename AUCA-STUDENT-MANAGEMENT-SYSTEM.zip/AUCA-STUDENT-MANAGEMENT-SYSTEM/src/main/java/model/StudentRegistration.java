package model;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "student_registration") // Renamed to follow Java naming conventions
public class StudentRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registration_id")
    private Long registrationId;

    @Column(name = "registration_code")
    private String registrationCode;

    @Column(name = "registration_date")
    private LocalDate registrationDate;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @ManyToOne
    @JoinColumn(name = "semester_id")
    private Semester semester;

	public StudentRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentRegistration(Long registrationId, String registrationCode, LocalDate registrationDate,
			Student student, Semester semester) {
		super();
		this.registrationId = registrationId;
		this.registrationCode = registrationCode;
		this.registrationDate = registrationDate;
		this.student = student;
		this.semester = semester;
	}

	public Long getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Long registrationId) {
		this.registrationId = registrationId;
	}

	public String getRegistrationCode() {
		return registrationCode;
	}

	public void setRegistrationCode(String registrationCode) {
		this.registrationCode = registrationCode;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Semester getSemester() {
		return semester;
	}

	public void setSemester(Semester semester) {
		this.semester = semester;
	}

    
}
