package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import model.Account;


public class Accountdao {
	 private SessionFactory sessionFactory;

	    public Accountdao() {
	        this.sessionFactory = HibernateUtil.getSessionFactory();
	    }

	    public void register(Account account) {
	        Transaction transaction = null;
	        try (Session session = sessionFactory.openSession()) {
	            transaction = session.beginTransaction();
	            session.save(account);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	    public Account authenticate(String email, String password) {
	        try (Session session = sessionFactory.openSession()) {
	            Query<Account> query = session.createQuery("FROM Account WHERE email = :email AND password = :password");
	            query.setParameter("email", email);
	            query.setParameter("password", password);
	            return query.uniqueResult();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

}
