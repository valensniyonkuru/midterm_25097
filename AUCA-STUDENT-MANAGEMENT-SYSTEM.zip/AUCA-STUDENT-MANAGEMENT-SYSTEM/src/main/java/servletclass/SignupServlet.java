package servletclass;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Account;
import dao.Accountdao;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	
    	 String email = request.getParameter("email");
         String fullName = request.getParameter("FullName");
         String newPassword = request.getParameter("newPassword");
         String role = request.getParameter("role");
         
         

         Account account = new Account();
         account.setEmail(email);
         account.setFullName(fullName);
         account.setPassword(newPassword);
         account.setRole(role); 
    
         
         Accountdao accountDao = new Accountdao();
         accountDao.register(account);

         response.sendRedirect("login.html");
}
}
