package dao;

import model.Teacher;
import org.hibernate.Session;
import org.hibernate.Transaction;
import dao.HibernateUtil;

public class TeacherDao {

    public void saveTeacher(Teacher teacher) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Begin transaction
            transaction = session.beginTransaction();

            // Save the teacher
            session.save(teacher);

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
