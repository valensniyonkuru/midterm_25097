package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import model.CourseDefinition;
import dao.HibernateUtil;

public class CourseDefinitionDao {

    public void saveCourseDefinition(CourseDefinition courseDefinition) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start a transaction
            transaction = session.beginTransaction();
            
            // Save the course definition
            session.save(courseDefinition);
            
            // Commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
