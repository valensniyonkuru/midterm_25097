package model;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.*;



@Entity
@Table(name = "semester")


public class Semester {
	 @Id
	    @Column(name = "id")
	 private String semester_id;

	 private String semester_name;

	 private LocalDate startDate;

	 private LocalDate endDate;

	public Semester() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Semester(String semester_id, String semester_name, LocalDate startDate, LocalDate endDate) {
		super();
		this.semester_id = semester_id;
		this.semester_name = semester_name;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public String getSemester_id() {
		return semester_id;
	}

	public void setSemester_id(String semester_id) {
		this.semester_id = semester_id;
	}

	public String getSemester_name() {
		return semester_name;
	}

	public void setSemester_name(String semester_name) {
		this.semester_name = semester_name;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

}