package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import model.StudentRegistration;
import dao.HibernateUtil;

public class StudentRegistrationDao {

    public void saveStudentRegistration(StudentRegistration studentRegistration) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start a transaction
            transaction = session.beginTransaction();
            
            // Save the student registration
            session.save(studentRegistration);
            
            // Commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
